"""Telegram-бот кофейни «Малина»: меню, бронь столика, напоминания."""
import asyncio
import html
import logging
import os
import re
import sqlite3
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (CallbackQuery, InlineKeyboardButton, KeyboardButton, Message,
                           ReplyKeyboardMarkup, ReplyKeyboardRemove)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID") or 0) or None   # куда слать новые брони
TZ = ZoneInfo(os.getenv("TIMEZONE", "Europe/Chisinau"))
TABLES = int(os.getenv("TABLES", "5"))                # столов на один час
FMT = "%Y-%m-%d %H:%M"
DAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]

BTN_BOOK, BTN_MENU = "🪑 Забронировать столик", "📋 Меню"
BTN_MY, BTN_INFO = "📅 Мои брони", "🕒 Часы и адрес"

MENU = """<b>☕ Кофе</b>
Эспрессо — 45 лей
Капучино — 65 лей
Раф малиновый — 85 лей
Фильтр-кофе — 60 лей

<b>🥐 Выпечка</b>
Круассан с маслом — 40 лей
Булочка с корицей — 45 лей
Тарт с малиной — 70 лей
Сырники — 80 лей

<b>🍵 Чай</b>
Чёрный с бергамотом — 70 лей
Зелёный сенча — 70 лей
Облепиховый с мёдом — 75 лей
Малиновый лимонад — 65 лей"""

INFO = """<b>Кофейня «Малина»</b>
📍 ул. Ляпунова, 12, Кишинёв
🕒 Пн–Пт: 7:30–21:00, Сб–Вс: 9:00–22:00
📞 +373 22 000 000"""

# ---------- база данных ----------
db = sqlite3.connect("bookings.db")
db.execute("""CREATE TABLE IF NOT EXISTS bookings(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, name TEXT,
    phone TEXT, guests INTEGER, starts_at TEXT,
    reminded INTEGER DEFAULT 0, status TEXT DEFAULT 'active')""")
db.commit()


def now() -> datetime:
    return datetime.now(TZ).replace(tzinfo=None)


def taken(start: datetime) -> int:
    row = db.execute("SELECT COUNT(*) FROM bookings WHERE status='active' AND starts_at=?",
                     (start.strftime(FMT),)).fetchone()
    return row[0]


def free_hours(day: datetime) -> list[int]:
    hours = range(9, 21) if day.weekday() >= 5 else range(8, 20)
    limit = now() + timedelta(minutes=30)
    return [h for h in hours
            if day.replace(hour=h) > limit and taken(day.replace(hour=h)) < TABLES]


# ---------- клавиатуры ----------
def main_kb() -> ReplyKeyboardMarkup:
    rows = [[KeyboardButton(text=BTN_BOOK)],
            [KeyboardButton(text=BTN_MENU), KeyboardButton(text=BTN_MY)],
            [KeyboardButton(text=BTN_INFO)]]
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)


def inline(buttons, width=3, cancel=True):
    kb = InlineKeyboardBuilder()
    for text, data in buttons:
        kb.button(text=text, callback_data=data)
    kb.adjust(width)
    if cancel:
        kb.row(InlineKeyboardButton(text="✖ Отмена", callback_data="stop"))
    return kb.as_markup()


class Booking(StatesGroup):
    day = State()
    hour = State()
    guests = State()
    name = State()
    phone = State()
    confirm = State()


router = Router()

# ---------- общие команды (регистрируются первыми) ----------
@router.message(CommandStart())
async def start(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(f"Привет, {html.escape(m.from_user.first_name)}! Я бот кофейни «Малина».\n"
                   "Покажу меню и помогу забронировать столик.", reply_markup=main_kb())


@router.message(Command("cancel"))
@router.callback_query(F.data == "stop")
async def stop(event, state: FSMContext):
    await state.clear()
    msg = event.message if isinstance(event, CallbackQuery) else event
    if isinstance(event, CallbackQuery):
        await event.answer()
    await msg.answer("Бронирование отменено.", reply_markup=main_kb())


@router.message(F.text == BTN_MENU)
async def show_menu(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(MENU)


@router.message(F.text == BTN_INFO)
async def show_info(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(INFO)


@router.message(F.text == BTN_MY)
async def my_bookings(m: Message, state: FSMContext):
    await state.clear()
    rows = db.execute("SELECT id, starts_at, guests FROM bookings WHERE user_id=? "
                      "AND status='active' AND starts_at>=? ORDER BY starts_at",
                      (m.from_user.id, now().strftime(FMT))).fetchall()
    if not rows:
        await m.answer("У вас нет активных броней.")
        return
    text = "\n".join(f"№{i}: {s}, гостей: {g}" for i, s, g in rows)
    await m.answer(f"<b>Ваши брони</b>\n{text}",
                   reply_markup=inline([(f"Отменить №{i}", f"x:{i}") for i, _, _ in rows],
                                       width=2, cancel=False))


@router.callback_query(F.data.startswith("x:"))
async def cancel_booking(cb: CallbackQuery):
    bid = int(cb.data[2:])
    db.execute("UPDATE bookings SET status='cancelled' WHERE id=? AND user_id=?",
               (bid, cb.from_user.id))
    db.commit()
    await cb.answer("Бронь отменена")
    await cb.message.answer(f"Бронь №{bid} отменена.")


# ---------- бронирование ----------
@router.message(F.text == BTN_BOOK)
async def book_start(m: Message, state: FSMContext):
    await state.clear()
    await state.set_state(Booking.day)
    today = now()
    days = [today + timedelta(days=i) for i in range(7)]
    buttons = [(("Сегодня" if i == 0 else f"{DAYS[d.weekday()]} {d:%d.%m}"),
                f"d:{d:%Y-%m-%d}") for i, d in enumerate(days)]
    await m.answer("На какой день?", reply_markup=inline(buttons))


@router.callback_query(Booking.day, F.data.startswith("d:"))
async def pick_day(cb: CallbackQuery, state: FSMContext):
    day = datetime.strptime(cb.data[2:], "%Y-%m-%d")
    hours = free_hours(day)
    if not hours:
        await cb.answer("На этот день мест нет, выберите другой", show_alert=True)
        return
    await state.update_data(day=cb.data[2:])
    await state.set_state(Booking.hour)
    await cb.message.edit_text(f"{day:%d.%m}. Во сколько?",
                               reply_markup=inline([(f"{h}:00", f"t:{h}") for h in hours], width=4))
    await cb.answer()


@router.callback_query(Booking.hour, F.data.startswith("t:"))
async def pick_hour(cb: CallbackQuery, state: FSMContext):
    await state.update_data(hour=int(cb.data[2:]))
    await state.set_state(Booking.guests)
    await cb.message.edit_text("Сколько гостей?",
                               reply_markup=inline([(str(n), f"g:{n}") for n in range(1, 9)], width=4))
    await cb.answer()


@router.callback_query(Booking.guests, F.data.startswith("g:"))
async def pick_guests(cb: CallbackQuery, state: FSMContext):
    await state.update_data(guests=int(cb.data[2:]))
    await state.set_state(Booking.name)
    await cb.message.edit_text("Как вас зовут? Напишите имя сообщением.")
    await cb.answer()


@router.message(Booking.name, F.text)
async def got_name(m: Message, state: FSMContext):
    await state.update_data(name=m.text.strip()[:50])
    await state.set_state(Booking.phone)
    kb = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True,
                             keyboard=[[KeyboardButton(text="📱 Отправить мой номер", request_contact=True)]])
    await m.answer("Номер телефона? Нажмите кнопку или напишите номер.", reply_markup=kb)


@router.message(Booking.phone, F.contact)
@router.message(Booking.phone, F.text)
async def got_phone(m: Message, state: FSMContext):
    phone = m.contact.phone_number if m.contact else m.text.strip()
    if len(re.sub(r"\D", "", phone)) < 7:
        await m.answer("Не похоже на номер. Попробуйте ещё раз, например +37360000000.")
        return
    await state.update_data(phone=phone)
    await state.set_state(Booking.confirm)
    d = await state.get_data()
    await m.answer("Почти готово.", reply_markup=ReplyKeyboardRemove())
    await m.answer(f"<b>Проверьте бронь</b>\n"
                   f"📅 {datetime.strptime(d['day'], '%Y-%m-%d'):%d.%m.%Y}, {d['hour']}:00\n"
                   f"👥 Гостей: {d['guests']}\n👤 {html.escape(d['name'])}\n📞 {html.escape(phone)}",
                   reply_markup=inline([("✅ Подтвердить", "ok")], width=1))


@router.callback_query(Booking.confirm, F.data == "ok")
async def confirm(cb: CallbackQuery, state: FSMContext, bot: Bot):
    d = await state.get_data()
    start_dt = datetime.strptime(d["day"], "%Y-%m-%d").replace(hour=d["hour"])
    await state.clear()
    if taken(start_dt) >= TABLES:
        await cb.message.edit_text("Это время только что заняли. Начните заново: «Забронировать столик».")
        await cb.message.answer("Выберите действие.", reply_markup=main_kb())
        return
    cur = db.execute("INSERT INTO bookings(user_id,name,phone,guests,starts_at) VALUES(?,?,?,?,?)",
                     (cb.from_user.id, d["name"], d["phone"], d["guests"], start_dt.strftime(FMT)))
    db.commit()
    await cb.message.edit_text(f"✅ Бронь №{cur.lastrowid} принята!\n"
                               f"Ждём вас {start_dt:%d.%m в %H:%M}. За 2 часа напомним.")
    await cb.message.answer("Выберите действие.", reply_markup=main_kb())
    if ADMIN_ID:
        await bot.send_message(ADMIN_ID, f"🆕 Бронь №{cur.lastrowid}: {start_dt.strftime(FMT)}, "
                               f"{d['guests']} гост., {html.escape(d['name'])}, {html.escape(d['phone'])}")
    await cb.answer()


# ---------- напоминания ----------
async def reminder_loop(bot: Bot):
    while True:
        try:
            current = now()
            rows = db.execute("SELECT id, user_id, starts_at FROM bookings WHERE status='active' "
                              "AND reminded=0 AND starts_at<=?",
                              ((current + timedelta(hours=2)).strftime(FMT),)).fetchall()
            for bid, uid, starts in rows:
                db.execute("UPDATE bookings SET reminded=1 WHERE id=?", (bid,))
                db.commit()
                if starts >= current.strftime(FMT):
                    await bot.send_message(uid, f"⏰ Напоминаем: сегодня в {starts[-5:]} ждём вас в «Малине» "
                                                f"(бронь №{bid}).")
        except Exception:
            logging.exception("Ошибка в напоминаниях")
        await asyncio.sleep(60)


async def main():
    if not TOKEN:
        raise SystemExit("Укажите BOT_TOKEN в файле .env")
    logging.basicConfig(level=logging.INFO)
    bot = Bot(TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)
    task = asyncio.create_task(reminder_loop(bot))
    try:
        await dp.start_polling(bot)
    finally:
        task.cancel()


if __name__ == "__main__":
    asyncio.run(main())
